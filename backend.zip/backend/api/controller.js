const Movie = require("../schemas/schema");
// const jwt = require("jsonwebtoken");
// const User = require("./schemas/user")
// const bcrypt = require("bcryptjs")
  
const addMovie = async (req, res) => {
  try {
    const { title, year, image } = req.body;
    const newMovie = new Movie({ title, year, image });
    await newMovie.save();
    res.json({ message: "Movie added successfully" });
  } catch (error) {
    console.error("Error adding movie:", error);
    res.status(404).json({ error: "Internal Server Error" });
  }
};

const getAllMovies = async (req, res) => {
  try {
    const movies = await Movie.find();
    res.json(movies);
  } catch (error) {
    console.error("Error getting movies:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const findMovie = async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.id);
    res.json(movie);
  } catch (error) {
    console.error("Error finding movie:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const editMovie = async (req, res) => {
  try {
    const { title, year, image } = req.body;
    await Movie.findByIdAndUpdate(req.params.id, { title, year, image });
    res.json({ message: "Movie updated successfully" });
  } catch (error) {
    console.error("Error editing movie:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};


module.exports = {
    
  addMovie,
  getAllMovies,
  findMovie,
  editMovie,
};

const express = require('express');
const router = express.Router();
const movieController = require('../api/controller');
const { verifyToken } = require('../middleware/auth');

router.post('/add',verifyToken, movieController.addMovie);
router.get('/all',verifyToken, movieController.getAllMovies);
router.get('/find/:id',verifyToken, movieController.findMovie);
router.put('/edit/:id',verifyToken, movieController.editMovie);
// router.post('/signup' , movieController.signup);
module.exports = router;

const mongoose = require('mongoose');

const movieSchema = new mongoose.Schema({
  title: { type: String, required: true },
  year: { type: Number, required: true },
  image: { type: String, required: true },
});
// const userschema = new mongoose.Schema({
//     email :{ type: String, required: true   }
//     ,password:{type:String,required:true}
// })
const Movie = mongoose.model('Movie', movieSchema);

module.exports = Movie;

